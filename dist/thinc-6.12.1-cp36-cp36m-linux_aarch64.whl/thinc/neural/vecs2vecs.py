from ._classes.convolution import ExtractWindow
