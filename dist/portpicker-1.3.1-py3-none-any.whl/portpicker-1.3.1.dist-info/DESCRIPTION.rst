Portpicker provides an API to find and return an available network
port for an application to bind to.  Ideally suited for use from
unittests or for test harnesses that launch local servers.

